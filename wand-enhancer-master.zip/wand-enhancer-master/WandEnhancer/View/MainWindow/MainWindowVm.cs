﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using WandEnhancer.Core;
using WandEnhancer.Core.Patching.Shared;
using WandEnhancer.Core.Services;
using WandEnhancer.Models;
using WandEnhancer.ReactiveUICore;
using WandEnhancer.Utils;
using WandEnhancer.View.Popups;
using Application = System.Windows.Application;

namespace WandEnhancer.View.MainWindow
{
    public class MainWindowVm : ObservableObject
    {
        private const string LogExportFilter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

        private readonly IShellView _shell;
        private readonly IFileDialogs _dialogs;
        public ObservableCollection<LogEntry> LogList { get; } = new ObservableCollection<LogEntry>();
        private WeModConfig _weModConfig;

        public WeModConfig WeModInfo
        {
            get => _weModConfig;
            set => SetProperty(ref _weModConfig, value);
        }

        private void UseInstall(WeModConfig config)
        {
            WeModInfo = config;
            if (config == null)
            {
                AlreadyPatched = false;
                CanRestore = false;
                IsPatchEnabled = false;
                return;
            }

            Log(LocalizationManager.Format("log_install_found", config, config.ExecutableName), ELogType.Success);
            AlreadyPatched = Enhancer.IsPatched(config.RootDirectory);
            CanRestore = Enhancer.HasBackup(config.RootDirectory);
            IsPatchEnabled = !AlreadyPatched;

            Log(LocalizationManager.Get(AlreadyPatched ? "log_already_patched" : "log_ready"),
                AlreadyPatched ? ELogType.Warn : ELogType.Info);

            // The root, not the app-* folder: Squirrel keeps the previous version folder, which would pin the old version after an update.
            string squirrelRoot = LauncherDeployment.SquirrelRootOf(config);
            var settings = SettingsManager.LoadSettings() ?? new AppSettings();
            if (settings.LastInstallPath != squirrelRoot)
            {
                settings.LastInstallPath = squirrelRoot;
                SettingsManager.SaveSettings(settings);
            }

            try
            {
                var newer = WeModInstalls.FindNewerInstall(squirrelRoot, config);
                if (newer != null)
                {
                    Log(LocalizationManager.Format("log_newer_version",
                        Path.GetFileName(newer.RootDirectory), newer.RootDirectory), ELogType.Warn);
                }
            }
            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException || e is ArgumentException)
            {
            }
        }

        private bool _isPatchEnabled;

        public bool IsPatchEnabled
        {
            get => _isPatchEnabled;
            set => SetProperty(ref _isPatchEnabled, value);
        }

        private bool _alreadyPatched;

        public bool AlreadyPatched
        {
            get => _alreadyPatched;
            set => SetProperty(ref _alreadyPatched, value);
        }

        private bool _canRestore;

        public bool CanRestore
        {
            get => _canRestore;
            set => SetProperty(ref _canRestore, value);
        }

        private bool _isBusy;

        /// <summary>True while a patch or restore runs.</summary>
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                if (SetProperty(ref _isBusy, value))
                {
                    OnPropertyChanged(nameof(IsIdle));
                }
            }
        }

        /// <summary>Bound by buttons that must not be clickable mid-run.</summary>
        public bool IsIdle => !_isBusy;

        public RelayCommand SetFolderPathCommand { get; }
        public RelayCommand ApplyPatchCommand { get; }
        public RelayCommand RestoreBackupCommand { get; }
        public RelayCommand OpenSettingsCommand { get; }
        public RelayCommand CopyLogsCommand { get; }
        public RelayCommand ExportLogsCommand { get; }
        public RelayCommand CopyDiagnosticsCommand { get; }
        public RelayCommand RescanInstallCommand { get; }

        private async void OnFolderPathSelection(object obj)
        {
            string selectedPath = _dialogs.PickFolder(
                LocalizationManager.Get("dialog_pick_install"),
                Environment.GetEnvironmentVariable("LOCALAPPDATA"));
            if (selectedPath != null)
            {
                await UseInstallPathAsync(selectedPath);
            }
        }

        private bool _isResolvingInstall;

        /// <summary>
        /// Picks the install from a folder or from the Wand executable inside one. Ignored while a run or
        /// another pick is active: the install must not change under them.
        /// </summary>
        public Task UseInstallPathAsync(string path) =>
            PickInstallAsync(
                () => WeModInstalls.ResolveInstall(File.Exists(path) ? Path.GetDirectoryName(path) : path),
                () => Log(LocalizationManager.Format("log_invalid_directory", Path.GetFileName(path)), ELogType.Error));

        private async Task PickInstallAsync(Func<WeModConfig> resolve, Action onMissing)
        {
            if (IsBusy || _isResolvingInstall)
            {
                return;
            }

            _isResolvingInstall = true;
            try
            {
                // Off the UI thread: a network share or a large folder must not freeze the window, or Explorer waiting on the drop.
                var info = await Task.Run(resolve);
                if (IsBusy)
                {
                    return;
                }

                if (info == null)
                {
                    onMissing();
                    return;
                }

                UseInstall(info);
            }
            finally
            {
                _isResolvingInstall = false;
            }
        }

        // Runs off the UI thread due to heavy file IO.
        private async void OnBackupRestoring(object param)
        {
            if (WeModInfo == null)
            {
                Log(LocalizationManager.Get("log_no_directory"), ELogType.Warn);
                return;
            }

            IsBusy = true;
            bool restored = await Task.Run(() =>
            {
                try
                {
                    OpenOperationLog("Restore");
                    new Enhancer(WeModInfo, LogAndRecord).Restore();
                    return true;
                }
                catch (Exception e)
                {
                    LogAndRecord(LocalizationManager.Format("log_restore_failed", e.Message), ELogType.Error);
                    LauncherLog.Write(e.ToString(), ELogType.Error);
                    return false;
                }
            });

            IsBusy = false;
            if (restored)
            {
                AlreadyPatched = false;
                CanRestore = false;
                IsPatchEnabled = true;
            }
        }

        private void OnPatching(object param)
        {
            if (WeModInfo == null)
            {
                Log(LocalizationManager.Get("log_no_directory"), ELogType.Warn);
                return;
            }

            _shell.OpenPopup(new PatchVectorsPopup(async config =>
            {
                _shell.ClosePopup();
                IsPatchEnabled = false;
                IsBusy = true;

                var settings = SettingsManager.LoadSettings() ?? new AppSettings();
                settings.LastPatchConfig = config;
                SettingsManager.SaveSettings(settings);
                await Task.Run(() =>
                {
                    try
                    {
                        OpenOperationLog($"Patch | patches {Program.DescribePatches(config)} | strategy {config.Strategy} | " +
                                         $"auto-apply {config.AutoApplyAfterUpdate}");
                        new Enhancer(WeModInfo, LogAndRecord, config).Patch();
                        AlreadyPatched = true;
                        CanRestore = true;
                    }
                    catch (Exception e)
                    {
                        LogAndRecord(LocalizationManager.Format("log_patch_failed", e.Message), ELogType.Error);
                        LauncherLog.Write(e.ToString(), ELogType.Error);
                        IsPatchEnabled = true;
                    }
                });
                IsBusy = false;
            }, SettingsManager.LoadSettings()?.LastPatchConfig), LocalizationManager.Get("pv_popup_title"));
        }

        // The current install first, so a manually picked one is rescanned too; the default locations only when it is gone.
        private async void OnRescanInstall(object param)
        {
            var current = WeModInfo;
            await PickInstallAsync(
                () => (current != null ? WeModInstalls.Rescan(LauncherDeployment.SquirrelRootOf(current), current) : null)
                      ?? WeModInstalls.FindWeMod(),
                () =>
                {
                    UseInstall(null);
                    Log(LocalizationManager.Get("log_install_not_found"), ELogType.Error);
                });
        }

        private void OnCopyDiagnostics(object param)
        {
            try
            {
                var builder = new StringBuilder();
                builder.AppendLine($"WandEnhancer: {Constants.Version} (build {Constants.Build})");
                builder.AppendLine($"OS: {Environment.OSVersion} | Runtime: {RuntimeInformation.FrameworkDescription}");
                if (WeModInfo != null)
                {
                    var folderVersion = WeModInstalls.ParseFolderVersion(Path.GetFileName(WeModInfo.RootDirectory));
                    builder.AppendLine($"Install: {WeModInfo.ExecutablePath}");
                    builder.AppendLine($"Client version: {(folderVersion.Major > 0 ? folderVersion.ToString() : "unknown")}");
                    builder.AppendLine($"Patched: {AlreadyPatched} | Backup present: {Enhancer.HasBackup(WeModInfo.RootDirectory)}");
                }
                else
                {
                    builder.AppendLine("Install: none found");
                }

                builder.AppendLine("--- session log ---");
                builder.Append(BuildLogReport());
                System.Windows.Clipboard.SetText(builder.ToString());
                Log(LocalizationManager.Get("log_copied"), ELogType.Success);
            }
            catch (Exception e)
            {
                Log(LocalizationManager.Format("log_copy_failed", e.Message), ELogType.Error);
            }
        }

        /// <summary>Starts a launcher.log section: a failed manual run must leave a file to attach to a bug report.</summary>
        private void OpenOperationLog(string operation)
        {
            LauncherLog.Open(LauncherDeployment.SquirrelRootOf(WeModInfo),
                $"WandEnhancer {Constants.Version} build {Constants.Build} | {operation} | {WeModInfo.ExecutablePath}");
        }

        private void LogAndRecord(string message, ELogType logType)
        {
            Log(message, logType);
            LauncherLog.Write(message, logType);
        }

        private void Log(string message, ELogType logType)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                var entry = new LogEntry
                {
                    LogType = logType,
                    Message = $"[{logType.ToString().ToUpper()}] {message}"
                };
                LogList.Add(entry);
                _shell.ScrollLogIntoView(entry);
                // Force CanExecute re-evaluation when appending log entries.
                System.Windows.Input.CommandManager.InvalidateRequerySuggested();
            });
        }

        private void OnOpenSettings(object param)
        {
            _shell.OpenPopup(new SettingsPopup(), LocalizationManager.Get("settings_title"));
        }

        private string BuildLogReport()
        {
            var builder = new StringBuilder();
            foreach (var entry in LogList)
            {
                builder.AppendLine(entry.Message);
            }
            return builder.ToString();
        }

        private void OnCopyLogs(object param)
        {
            try
            {
                System.Windows.Clipboard.SetText(BuildLogReport());
                Log(LocalizationManager.Get("log_copied"), ELogType.Success);
            }
            catch (Exception e)
            {
                Log(LocalizationManager.Format("log_copy_failed", e.Message), ELogType.Error);
            }
        }

        private void OnExportLogs(object param)
        {
            string path = _dialogs.PickSaveFile(
                LogExportFilter,
                $"wand-enhancer-log-{DateTime.Now:yyyyMMdd-HHmmss}.txt");
            if (path == null)
            {
                return;
            }

            try
            {
                File.WriteAllText(path, BuildLogReport());
                Log(LocalizationManager.Format("log_exported", path), ELogType.Success);
            }
            catch (Exception e)
            {
                Log(LocalizationManager.Format("log_export_failed", e.Message), ELogType.Error);
            }
        }

        private bool HasLogs(object param) => LogList.Count > 0;

        /// <summary>Displays the repository URL if the browser fails to open.</summary>
        public void ReportRepositoryLinkFailure(string url)
        {
            Log(LocalizationManager.Format("log_open_link_failed", url), ELogType.Warn);
        }

        public MainWindowVm(IShellView shell, IFileDialogs dialogs)
        {
            _shell = shell;
            _dialogs = dialogs;
            SetFolderPathCommand = new RelayCommand(OnFolderPathSelection);
            ApplyPatchCommand = new RelayCommand(OnPatching);
            RestoreBackupCommand = new RelayCommand(OnBackupRestoring);
            OpenSettingsCommand = new RelayCommand(OnOpenSettings);
            CopyLogsCommand = new RelayCommand(OnCopyLogs, HasLogs);
            ExportLogsCommand = new RelayCommand(OnExportLogs, HasLogs);
            CopyDiagnosticsCommand = new RelayCommand(OnCopyDiagnostics);
            RescanInstallCommand = new RelayCommand(OnRescanInstall);

            var saved = SettingsManager.LoadSettings();
            var resolved = !string.IsNullOrEmpty(saved?.LastInstallPath)
                ? WeModInstalls.ResolveInstall(saved.LastInstallPath)
                : null;
            UseInstall(resolved ?? WeModInstalls.FindWeMod());
            if (WeModInfo == null)
            {
                Log(LocalizationManager.Get("log_install_not_found"), ELogType.Error);
            }

            foreach (var entry in Program.StartupLog)
            {
                Log(entry.Key, entry.Value);
            }
            Program.StartupLog.Clear();

#if ENABLE_UPDATE_NOTIFICATIONS
            ShowUpdateCommand = new RelayCommand(OnShowUpdate);
            UpdateNotifier.CheckInBackground(OnUpdateFound, OnNotificationClick);
#endif
        }

#if ENABLE_UPDATE_NOTIFICATIONS
        private UpdateNotifier.UpdateRelease _availableUpdate;
        private bool _isUpdateAvailable;

        public bool IsUpdateAvailable
        {
            get => _isUpdateAvailable;
            private set => SetProperty(ref _isUpdateAvailable, value);
        }

        public RelayCommand ShowUpdateCommand { get; }

        private void OnShowUpdate(object param)
        {
            if (_availableUpdate != null)
                OpenUpdatePopup(_availableUpdate);
        }

        private void OnUpdateFound(UpdateNotifier.UpdateRelease update)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                _availableUpdate = update;
                IsUpdateAvailable = true;
            });
        }

        private void OnNotificationClick(UpdateNotifier.UpdateRelease update)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                var window = Application.Current.MainWindow;
                if (window != null)
                {
                    window.Topmost = true;
                    window.Activate();
                    window.Topmost = false;
                }

                OpenUpdatePopup(update);
            });
        }

        private void OpenUpdatePopup(UpdateNotifier.UpdateRelease update)
        {
            _shell.OpenPopup(
                new UpdatePopup(Constants.Version.ToString(), update.Version, update.Notes,
                    update.Url, UpdateNotifier.GetFullChangelogAsync),
                LocalizationManager.Get("up_popup_title"));
        }
#endif
    }
}
